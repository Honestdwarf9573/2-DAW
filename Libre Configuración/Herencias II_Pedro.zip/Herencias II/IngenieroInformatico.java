//Hecho por Pedro González

public class IngenieroInformatico extends Ingeniero {
    public void crearPrograma() {
       System.out.println("Vamos a hacer un tren");
       System.out.println();
       System.out.println(" locomotora");
       //Se supone que es una locomotora, pero no sale bien
       System.out.println(" __________");
       System.out.println("|  ______  |____");
       System.out.println("| |      | |    |]");
       System.out.println("| |______| |____|");
       System.out.println("|__________|");
   
    }
}
