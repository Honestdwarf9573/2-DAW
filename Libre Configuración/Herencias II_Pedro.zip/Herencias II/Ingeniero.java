//Hecho por Pedro González
public class Ingeniero extends Persona {
    public void razonar() {
        System.out.println("Esto no tiene sentido,vamos a intentar razonar lentamente");
    }

    public void trabajarEnGrupo() {
        System.out.println("No nos precipitemos, vamos a colaborar todos juntos");
    }
}
